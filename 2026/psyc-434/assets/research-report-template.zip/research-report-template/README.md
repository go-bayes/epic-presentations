# Research-report template (PSYC 434, Option A)

This folder is the scaffold for the 2026 Option A research report.

## Start here

1. Open this folder in RStudio or another editor.
2. Open `setup.R` and choose one exposure:

   ```r
   name_exposure <- "religious_service"   # or "volunteer_work"
   ```

3. Leave `outcome_short_names` unchanged. The report must analyse all four wellbeing outcomes: purpose, belonging, self-esteem, and life satisfaction.
4. Run the setup script once before working in the manuscript:

   ```sh
   Rscript setup.R
   ```

   The first run may take about 5 to 10 minutes while required materials and packages install.
5. Render the report:

   ```sh
   quarto render manuscript.qmd
   ```

6. Open the PDF in `_output/` and check that it rendered.
7. Replace the placeholder text in `manuscript.qmd` with your own writing.
8. Render again before submitting.

## Files

| File | Role |
|---|---|
| `setup.R` | Study decisions, packages, helper functions, and the four-outcome analysis pipeline. |
| `manuscript.qmd` | The report text, tables, figures, appendix, and citations. |
| `_quarto.yml` | Quarto render settings. |
| `references.bib` | References used by the report. Add any extra sources here. |
| `apa.csl` | APA citation style. |
| `_output/` | Rendered PDF and HTML, created after rendering. |

## Adding citations with BibTeX

The template uses `references.bib` for citations. Add each source to that file, then cite it from `manuscript.qmd`.

To add one source from Google Scholar:

1. Search for the exact article title in [Google Scholar](https://scholar.google.com/).
2. Choose the correct record. Prefer the publisher version or a record with a Digital Object Identifier (DOI) when there are duplicates.
3. Click the quotation-mark cite icon, or the `Cite` link if that is what your browser shows.
4. Click `BibTeX`.
5. Copy the full entry, from `@article{...` or `@book{...` through the closing `}`.
6. Paste it at the bottom of `references.bib`.
7. Rename the key to something readable, such as `vanderweele2020` or `smith2024wellbeing`.
8. Cite it in `manuscript.qmd` with `[@vanderweele2020]` or use an in-text citation such as `@vanderweele2020`.
9. Render the manuscript. If Quarto reports a missing citation, check that the citation key in the `.qmd` exactly matches the key in `references.bib`.

A BibTeX entry looks like this:

```bibtex
@article{vanderweele2020,
  title = {Outcome-wide Epidemiology},
  author = {VanderWeele, Tyler J.},
  journal = {Epidemiology},
  year = {2020},
  volume = {31},
  number = {1},
  pages = {6--9},
  doi = {10.1097/EDE.0000000000001141}
}
```

Check Google Scholar entries before trusting them. Fix obvious errors in capitalisation, missing journal names, missing DOIs, page ranges, or author names. For title capitalisation that must be preserved in APA style, protect proper nouns with braces, for example `title = {Te Tiriti o Waitangi and Wellbeing}`.

## Submit

Submit the rendered PDF with the R code appendix through Nuku by the due date listed on the course Assessments page.

Do not submit the `.qmd`, `.R`, or `.bib` files unless asked.
