# ============================================================================
# PSYC 434 -- research-report-template / setup.R
# ----------------------------------------------------------------------------
# Change the exposure here. The manuscript analyses all four wellbeing
# outcomes for that exposure.
# ============================================================================

# --- packages ---------------------------------------------------------------

required_packages <- c(
  "causalworkshop", "grf", "ggdag", "ggplot2", "dplyr", "tibble",
  "knitr", "kableExtra"
)

missing <- required_packages[
  !vapply(required_packages, \(p) requireNamespace(p, quietly = TRUE), logical(1))
]

if ("causalworkshop" %in% missing) {
  if (!requireNamespace("pak", quietly = TRUE)) install.packages("pak")
  pak::pak("go-bayes/causalworkshop")
  missing <- setdiff(missing, "causalworkshop")
}

if (length(missing) > 0) {
  install.packages(missing, repos = "https://cloud.r-project.org")
}

suppressPackageStartupMessages({
  library(causalworkshop)
  library(grf)
  library(ggdag)
  library(ggplot2)
  library(dplyr)
  library(tibble)
  library(knitr)
  library(kableExtra)
})

# --- study constants --------------------------------------------------------

# Choose one: "religious_service" or "volunteer_work".
# Do not use "community_group"; that exposure is reserved for the Lab 9
# worked example.
name_exposure <- "religious_service"

outcome_names <- c("purpose", "belonging", "self_esteem", "life_satisfaction")

study_n <- 1000
study_seed <- 2026

covariate_cols <- c(
  "age", "male", "nz_european", "education", "partner", "employed",
  "log_income", "nz_dep", "agreeableness", "conscientiousness",
  "extraversion", "neuroticism", "openness"
)

# Baseline exposure and baseline outcomes are lagged-self covariates.
adjustment_cols <- c(covariate_cols, name_exposure, outcome_names)

label_mapping <- list(
  religious_service = "religious-service attendance",
  volunteer_work = "volunteer work",
  community_group = "community-group participation",
  purpose = "sense of purpose",
  belonging = "belonging",
  self_esteem = "self-esteem",
  life_satisfaction = "life satisfaction"
)

label_for <- function(key) {
  if (!is.null(label_mapping[[key]])) label_mapping[[key]] else key
}

stop_if_invalid_exposure <- function() {
  if (!name_exposure %in% c("religious_service", "volunteer_work")) {
    stop(
      "name_exposure must be 'religious_service' or 'volunteer_work'. ",
      "'community_group' is reserved for Lab 9.",
      call. = FALSE
    )
  }
}

# --- plot defaults ----------------------------------------------------------

study_palette <- list(
  primary = "#0072B2",
  accent = "#E69F00",
  neutral = "#666666",
  pale = "#D9EAF7"
)

theme_set(
  theme_minimal(base_size = 11) +
    theme(
      panel.grid.minor = element_blank(),
      plot.title.position = "plot",
      strip.text = element_text(face = "bold")
    )
)

fig_w <- 6.5
fig_h <- 4

# --- data -------------------------------------------------------------------

.exposure_short <- function(x) {
  switch(
    x,
    religious_service = "religious",
    volunteer_work = "volunteer",
    community_group = "community",
    x
  )
}

simulate_panel <- function(n = study_n, seed = study_seed) {
  stop_if_invalid_exposure()

  d <- causalworkshop::simulate_nzavs_data(n = n, seed = seed)
  d0 <- d |> filter(wave == 0)
  d1 <- d |> filter(wave == 1)
  d2 <- d |> filter(wave == 2)

  out <- as_tibble(d0[, adjustment_cols])
  out$exposure <- d1[[name_exposure]]

  for (outcome in outcome_names) {
    out[[paste0("y_", outcome)]] <- d2[[outcome]]
    out[[paste0("tau_true_", outcome)]] <-
      d0[[paste0("tau_", .exposure_short(name_exposure), "_", outcome)]]
  }

  out
}

# --- analysis helpers -------------------------------------------------------

fit_one_outcome <- function(data, outcome, num_trees = 500) {
  X <- as.matrix(data[, adjustment_cols])
  W <- data$exposure
  Y <- data[[paste0("y_", outcome)]]

  cf <- causal_forest(
    X, Y, W,
    num.trees = num_trees,
    honesty = TRUE,
    seed = study_seed
  )

  ate <- average_treatment_effect(cf)
  tau_hat <- predict(cf)$predictions

  list(
    outcome = outcome,
    forest = cf,
    ate = ate,
    tau_hat = tau_hat
  )
}

fit_all_outcomes <- function(data, num_trees = 500) {
  setNames(
    lapply(outcome_names, \(outcome) fit_one_outcome(data, outcome, num_trees)),
    outcome_names
  )
}

evalue_from_smd <- function(x) {
  # VanderWeele-style approximation for continuous outcomes on a
  # standardised scale: SMD -> approximate RR -> E-value.
  rr <- exp(0.91 * abs(x))
  ifelse(rr <= 1, 1, rr + sqrt(rr * (rr - 1)))
}

ate_table <- function(fits, alpha_fw = 0.05) {
  k <- length(fits)
  alpha_each <- alpha_fw / k
  z_bonf <- qnorm(1 - alpha_each / 2)

  bind_rows(lapply(fits, function(fit) {
    est <- unname(fit$ate["estimate"])
    se <- unname(fit$ate["std.err"])
    ci_low <- est - 1.96 * se
    ci_high <- est + 1.96 * se
    ci_bonf_low <- est - z_bonf * se
    ci_bonf_high <- est + z_bonf * se
    bound_closest_null <- if (ci_bonf_low > 0) ci_bonf_low else if (ci_bonf_high < 0) ci_bonf_high else 0

    tibble(
      outcome = fit$outcome,
      outcome_label = label_for(fit$outcome),
      estimate = est,
      std_error = se,
      ci_low = ci_low,
      ci_high = ci_high,
      bonferroni_ci_low = ci_bonf_low,
      bonferroni_ci_high = ci_bonf_high,
      e_value = evalue_from_smd(est),
      e_value_bound = evalue_from_smd(bound_closest_null)
    )
  })) |>
    arrange(desc(abs(estimate)))
}

forest_plot <- function(results) {
  results |>
    mutate(outcome_label = reorder(outcome_label, estimate)) |>
    ggplot(aes(x = estimate, y = outcome_label)) +
    geom_vline(xintercept = 0, linetype = "dashed", colour = study_palette$neutral) +
    geom_errorbar(
      aes(xmin = bonferroni_ci_low, xmax = bonferroni_ci_high),
      width = 0.15,
      colour = study_palette$primary
    ) +
    geom_point(size = 2.4, colour = study_palette$accent) +
    labs(
      x = "average treatment effect (standard-deviation units)",
      y = NULL
    )
}

descriptives_table <- function(data) {
  vars <- c("age", "male", "partner", "log_income", name_exposure, outcome_names)
  bind_rows(lapply(vars, function(v) {
    x <- data[[v]]
    tibble(
      variable = v,
      label = label_for(v),
      mean = mean(x),
      sd = sd(x)
    )
  }))
}

policy_tree_guidance <- function(results) {
  results |>
    transmute(
      outcome = outcome_label,
      `what to report` = paste0(
        "Fit a depth-2 policy tree for ", outcome_label,
        "; translate the treat leaves into plain language; report policy value ",
        "with a 95% CI; compare with depth 1 using the parsimony rule."
      )
    )
}
