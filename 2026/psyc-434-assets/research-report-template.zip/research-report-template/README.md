# Research-report template (PSYC 434, Option A)

A minimal Quarto scaffold for the 2026 Option A report.

You choose one exposure and analyse all four wellbeing outcomes. The
third simulator exposure, `community_group`, is reserved for the Lab 9
worked example and must not be used for the report.

## Quick start

1. **Copy the directory** into your own GitHub Classroom repository:

   ```sh
   cp -R /path/to/26-434/research-report-template ./my-research-report
   cd my-research-report
   ```

2. **Edit `setup.R`** to choose your exposure:

   ```r
   name_exposure <- "religious_service"   # or "volunteer_work"
   ```

   Leave `outcome_names` unchanged unless the course coordinator tells
   you otherwise. The report is outcome-wide: purpose, belonging,
   self-esteem, and life satisfaction are all required.

3. **Render the manuscript**:

   ```sh
   quarto render manuscript.qmd
   ```

   Output appears in `_output/`. The first render is slowest because it
   installs missing R packages; subsequent renders take 15-30 seconds.

4. **Edit the prose** section by section. Each top-level heading in
   `manuscript.qmd` corresponds to the Option A criteria listed in
   `assessments.md`. Replace the placeholder paragraphs with your own
   analysis and argument.

## What lives where

| File | Role |
|---|---|
| `setup.R` | Packages, constants, label mappings, plot defaults, helpers, and four-outcome fitting functions. |
| `manuscript.qmd` | The report. Sources `setup.R`. Includes runnable causal-forest fits for all four outcomes. |
| `_quarto.yml` | Render options (PDF + HTML, lualatex, bibliography path) |
| `references.bib` | Starter citations. Add your own in BibTeX format. |
| `_output/` | Rendered PDF and HTML (created on first render) |

## Required software

- R (≥ 4.2)
- Quarto (≥ 1.4)
- LuaLaTeX (bundled with TinyTeX or any TeX distribution)
- The R packages listed at the top of `setup.R`. Missing packages
  install automatically on first render.

## Adapting the template

The cleanest workflow is to keep the template intact and edit only:

- `setup.R` for study-level choices (exposure, covariates, sample size).
- `manuscript.qmd` for prose and any additional analysis chunks.
- `references.bib` for new citations.

Avoid hard-coding values inside `manuscript.qmd`. Anything that might
change later belongs in `setup.R`.

## What the template does not do automatically

The policy-tree section is a reporting scaffold. Lab 9 shows the full
`margot` workflow for policy trees, stability checks, Qini curves, and
RATE summaries. Use that workflow to generate the final policy-tree
figures and policy values for your chosen exposure.
